import React, { useState } from 'react';
import Head from 'next/head';

const AddProduct = () => {
  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    description: '',
    price: 0,
    images: [],
    category: '',
    color: '',
    material: '',
    weight: 0,
    dimensions: '',
    stock: 0
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({ ...prevState, [name]: value }));
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const fileUrls = files.map(file => URL.createObjectURL(file));
    setFormData(prevState => ({ ...prevState, images: fileUrls }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });
    if (res.ok) {
      alert('Product added successfully');
    }
  };

  return (
    <>
      <Head>
        <title>Add Product - Eternal Elegance Emporium</title>
      </Head>
      <div className="container">
        <h1>Add New Product</h1>
        <form onSubmit={handleSubmit}>
          <label>Name: <input type="text" name="name" value={formData.name} onChange={handleChange} required /></label>
          <label>Brand: <input type="text" name="brand" value={formData.brand} onChange={handleChange} required /></label>
          <label>Description: <textarea name="description" value={formData.description} onChange={handleChange} required /></label>
          <label>Price: <input type="number" name="price" value={formData.price} onChange={handleChange} required /></label>
          <label>Images: <input type="file" accept="image/*" multiple onChange={handleImageUpload} /></label>
          <label>Category: <input type="text" name="category" value={formData.category} onChange={handleChange} required /></label>
          <label>Color: <input type="text" name="color" value={formData.color} onChange={handleChange} required /></label>
          <label>Material: <input type="text" name="material" value={formData.material} onChange={handleChange} required /></label>
          <label>Weight (grams): <input type="number" name="weight" value={formData.weight} onChange={handleChange} required /></label>
          <label>Dimensions (cm): <input type="text" name="dimensions" value={formData.dimensions} onChange={handleChange} required /></label>
          <label>Stock: <input type="number" name="stock" value={formData.stock} onChange={handleChange} required /></label>
          <button type="submit">Add Product</button>
        </form>
      </div>

      <style jsx>{`
        .container {
          padding: 20px;
          max-width: 600px;
          margin: auto;
        }
        form {
          display: flex;
          flex-direction: column;
        }
        label {
          margin-bottom: 15px;
        }
        input, textarea {
          width: 100%;
          padding: 10px;
          margin-top: 5px;
        }
        button {
          padding: 10px;
          background-color: #b69e64;
          color: white;
          border: none;
          border-radius: 5px;
          cursor: pointer;
        }
      `}</style>
    </>
  );
};

export default AddProduct;
