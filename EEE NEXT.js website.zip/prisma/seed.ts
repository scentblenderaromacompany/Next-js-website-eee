import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Create example categories
  const ringsCategory = await prisma.category.create({ data: { name: 'Rings' } });
  const necklacesCategory = await prisma.category.create({ data: { name: 'Necklaces' } });

  // Create example products
  await prisma.product.create({
    data: {
      name: 'Diamond Ring',
      description: 'A beautiful diamond ring.',
      price: 299.99,
      imageUrl: '/images/ring.jpg',
      categoryId: ringsCategory.id,
    },
  });

  await prisma.product.create({
    data: {
      name: 'Gold Necklace',
      description: 'An elegant gold necklace.',
      price: 199.99,
      imageUrl: '/images/necklace.jpg',
      categoryId: necklacesCategory.id,
    },
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });