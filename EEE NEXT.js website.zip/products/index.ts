import React, { useState, useEffect } from 'react';
import Head from 'next/head';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [filter, setFilter] = useState({ category: '', priceRange: [0, 1000] });

  useEffect(() => {
    fetchProducts();
  }, [filter]);

  const fetchProducts = async () => {
    const query = new URLSearchParams(filter).toString();
    const res = await fetch(`/api/products?${query}`);
    const data = await res.json();
    setProducts(data);
  };

  return (
    <>
      <Head>
        <title>Products - Eternal Elegance Emporium</title>
      </Head>
      <div className="container">
        <h1>Our Products</h1>
        <div className="filter-container">
          <label>
            Category:
            <select onChange={e => setFilter({ ...filter, category: e.target.value })}>
              <option value="">All</option>
              <option value="Rings">Rings</option>
              <option value="Necklaces">Necklaces</option>
              <option value="Bracelets">Bracelets</option>
              <option value="Earrings">Earrings</option>
              <option value="Watches">Watches</option>
            </select>
          </label>
          <label>
            Price Range:
            <input type="range" min="0" max="1000" value={filter.priceRange[1]} onChange={e => setFilter({ ...filter, priceRange: [0, e.target.value] })} />
            {`$${filter.priceRange[0]} - $${filter.priceRange[1]}`}
          </label>
        </div>
        <div className="products-grid">
          {products.map(product => (
            <div key={product.id} className="product-card">
              <img src={product.images[0]} alt={product.name} />
              <h2>{product.name}</h2>
              <p>{product.brand}</p>
              <p>{product.material}</p>
              <p>{product.color}</p>
              <p>{product.price}</p>
              <button>Add to Cart</button>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .container {
          padding: 20px;
        }
        .filter-container {
          display: flex;
          justify-content: space-between;
          margin-bottom: 20px;
        }
        .products-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
          gap: 20px;
        }
        .product-card {
          padding: 20px;
          background-color: #fff;
          border: 1px solid #ccc;
          border-radius: 5px;
        }
    </style>
    </>

export default Products;