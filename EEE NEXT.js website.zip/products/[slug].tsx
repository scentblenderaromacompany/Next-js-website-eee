import React from 'react';
import { GetStaticPaths, GetStaticProps } from 'next';
import { fetchProductBySlug, fetchProductSlugs } from '../../lib/stripe';

const ProductPage = ({ product }) => {
  return (
    <div className="container mx-auto">
      <h1 className="text-2xl font-bold text-primary">{product.name}</h1>
      <div className="my-4">
        <img src={product.images[0]} alt={product.name} className="w-full h-auto" />
      </div>
      <p className="text-lg text-secondary">{product.description}</p>
      <p className="text-lg text-accent mt-4">Material: {product.metadata.material}</p>
      <p className="text-lg text-accent mt-2">Condition: {product.metadata.condition}</p>
      <p className="text-xl font-bold text-primary mt-6">Price: ${product.price / 100}</p>
      <button className="bg-primary text-white py-2 px-4 mt-4">Add to Cart</button>
    </div>
  );
};

export const getStaticPaths: GetStaticPaths = async () => {
  const slugs = await fetchProductSlugs();
  return {
    paths: slugs.map(slug => ({ params: { slug } })),
    fallback: false,
  };
};

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const product = await fetchProductBySlug(params.slug);
  return {
    props: {
      product,
    },
  };
};

export default ProductPage;