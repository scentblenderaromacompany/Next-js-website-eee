import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2022-11-15',
});

export const fetchProducts = async () => {
  const products = await stripe.products.list({ limit: 10 });
  return products.data.map(product => ({
    id: product.id,
    name: product.name,
    slug: product.metadata.slug,
    description: product.description,
    images: product.images,
    price: product.metadata.price,
    metadata: product.metadata,
  }));
};

export const fetchProductBySlug = async (slug: string) => {
  const product = await stripe.products.list({ limit: 1, active: true, metadata: { slug } });
  const price = await stripe.prices.retrieve(product.data[0].default_price as string);
  return {
    ...product.data[0],
    price: price.unit_amount,
  };
};

export const fetchProductSlugs = async () => {
  const products = await stripe.products.list({ limit: 10 });
  return products.data.map(product => product.metadata.slug);
};