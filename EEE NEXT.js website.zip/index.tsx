import React from 'react';
import Head from 'next/head';
import HeroImage from '../components/HeroImage';
import ProductCarousel from '../components/ProductCarousel';
import InstagramFeed from '../components/InstagramFeed';
import EbayProducts from '../components/EbayProducts';

const Home = ({ products }) => {
  return (
    <>
      <Head>
        <title>Home - Eternal Elegance Emporium</title>
      </Head>
      <HeroImage />
      <ProductCarousel products={products} />
      <InstagramFeed />
      <EbayProducts />

      {/* Subscription Box */}
      <div className="subscription-container">
        <header>Subscribe Today And Join Our Community!</header>
        <div className="modal" id="planModal">
          <main id="planDetails">Please select a plan below to see the details.</main>
        </div>
        <div className="features-list" id="featuresList"></div>
        <div id="buttonsContainer">
          <button className="plan-button" onClick={() => selectPlan('Bronze')}>Bronze</button>
          <button className="plan-button" onClick={() => selectPlan('Silver')}>Silver</button>
          <button className="plan-button" onClick={() => selectPlan('Gold')}>Gold</button>
        </div>
      </div>

      <style jsx>{`
        .subscription-container {
          padding: 50px 20px;
          background-color: #f0e6d2;
          text-align: center;
          border-top: 2px solid #c4a678;
          border-bottom: 2px solid #c4a678;
          margin: 50px 0;
        }
        header {
          font-family: 'Playfair Display', serif;
          font-size: 36px;
          font-weight: bold;
          margin-bottom: 30px;
        }
        .modal {
          background-color: #f0e6d2;
          padding: 12px;
          border: 2px solid #8b4513;
          width: 270px;
          height: 180px;
          display: flex;
          justify-content: center;
          align-items: center;
          margin: 0 auto 30px; /* Centering the modal and spacing */
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        main {
          font-size: 21px;
          font-weight: semi-bold;
          color: black;
        }
        .plan-button {
          padding: 8px 16px;
          margin: 4px;
          border: 2px solid #000;
          background-color: #fff;
          color: black;
          cursor: pointer;
          font-size: 14px;
          display: inline-block;
        }
        .plan-button:hover {
          background-color: #f5f5f5;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        .features-list {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          margin: 0 auto 10px;
        }
        .features-list div {
          display: flex;
          align-items: center;
          margin: 5px 0;
        }
        .separator {
          height: 20px;
          width: 1px;
          background-color: #000;
          margin: 0 5px;
        }
        .feature {
          margin: 0 10px;
          color: black;
        }
        @media (max-width: 768px) {
          .modal {
            width: 100%;
            height: auto;
          }
          .plan-button {
            width: 100%;
            margin-bottom: 10px;
          }
        }
      `}</style>

      <script>
        var features = {
            'Bronze': ['Basic support', 'Monthly updates', 'Email notifications', '24/7 Customer service'],
            'Silver': ['Priority support', 'Weekly updates', 'Free consultation', 'Extended warranty', 'Cloud storage', 'API access'],
            'Gold': ['24/7 support', 'Daily updates', 'Personal consultant', 'Onsite service', 'Premium content access', 'Analytics dashboard', 'Custom reports']
        };

        function selectPlan(plan) {
            var modal = document.getElementById('planModal');
            var details = document.getElementById('planDetails');
            var featuresList = document.getElementById('featuresList');
            var accumulatedFeatures = features[plan];

            modal.style.backgroundColor = {'Bronze': '#d2b48c', 'Silver': '#c0c0c0', 'Gold': '#fdd835'}[plan];
            modal.style.borderColor = {'Bronze': '#8b4513', 'Silver': '#708090', 'Gold': '#c6a700'}[plan];
            details.textContent = 'Enjoy the benefits of our ' + plan.toLowerCase() + ' package.';
            featuresList.innerHTML = '';

            accumulatedFeatures.forEach((feature, index) => {
                let div = document.createElement('div');
                let featureSpan = document.createElement('span');
                featureSpan.textContent = feature;
                featureSpan.className = 'feature';
                div.appendChild(featureSpan);

                if (index % 4 !== 0) {
                    let separator = document.createElement('div');
                    separator.className = 'separator';
                    div.insertBefore(separator, featureSpan);
                }
                featuresList.appendChild(div);
            });

            document.querySelectorAll('.plan-button').forEach(button => {
                button.style.backgroundColor = '#ffffff';
                button.style.borderColor = '#000000';
                button.style.color = '#000000';
                if (button.textContent === plan) {
                    button.style.backgroundColor = {'Bronze': '#d2b48c', 'Silver': '#c0c0c0', 'Gold': '#fdd835'}[plan];
                    button.style.borderColor = {'Bronze': '#8b4513', 'Silver': '#708090', 'Gold': '#c6a700'}[plan];
                    button.style.color = '#ffffff';
                }
            });
        }
      </script>
    </>
  );
};

export async function getStaticProps() {
  // Fetch the products from your database
  const products = await fetchProducts();
  return {
    props: {
      products,
    },
  };
}

export default Home;import React from 'react';
import Head from 'next/head';
import HeroImage from '../components/HeroImage';
import ProductCarousel from '../components/ProductCarousel';
import InstagramFeed from '../components/InstagramFeed';
import EbayProducts from '../components/EbayProducts';

const Home = ({ products }) => {
  return (
    <>
      <Head>
        <title>Home - Eternal Elegance Emporium</title>
      </Head>
      <HeroImage />
      <ProductCarousel products={products} />
      <InstagramFeed />
      <EbayProducts />

      {/* Subscription Box */}
      <div className="subscription-container">
        <header>Subscribe Today And Join Our Community!</header>
        <div className="modal" id="planModal">
          <main id="planDetails">Please select a plan below to see the details.</main>
        </div>
        <div className="features-list" id="featuresList"></div>
        <div id="buttonsContainer">
          <button className="plan-button" onClick={() => selectPlan('Bronze')}>Bronze</button>
          <button className="plan-button" onClick={() => selectPlan('Silver')}>Silver</button>
          <button className="plan-button" onClick={() => selectPlan('Gold')}>Gold</button>
        </div>
      </div>

      <style jsx>{`
        .subscription-container {
          padding: 50px 20px;
          background-color: #f0e6d2;
          text-align: center;
          border-top: 2px solid #c4a678;
          border-bottom: 2px solid #c4a678;
          margin: 50px 0;
        }
        header {
          font-family: 'Playfair Display', serif;
          font-size: 36px;
          font-weight: bold;
          margin-bottom: 30px;
        }
        .modal {
          background-color: #f0e6d2;
          padding: 12px;
          border: 2px solid #8b4513;
          width: 270px;
          height: 180px;
          display: flex;
          justify-content: center;
          align-items: center;
          margin: 0 auto 30px; /* Centering the modal and spacing */
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        main {
          font-size: 21px;
          font-weight: semi-bold;
          color: black;
        }
        .plan-button {
          padding: 8px 16px;
          margin: 4px;
          border: 2px solid #000;
          background-color: #fff;
          color: black;
          cursor: pointer;
          font-size: 14px;
          display: inline-block;
        }
        .plan-button:hover {
          background-color: #f5f5f5;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        .features-list {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          margin: 0 auto 10px;
        }
        .features-list div {
          display: flex;
          align-items: center;
          margin: 5px 0;
        }
        .separator {
          height: 20px;
          width: 1px;
          background-color: #000;
          margin: 0 5px;
        }
        .feature {
          margin: 0 10px;
          color: black;
        }
        @media (max-width: 768px) {
          .modal {
            width: 100%;
            height: auto;
          }
          .plan-button {
            width: 100%;
            margin-bottom: 10px;
          }
        }
      `}</style>

      <script>
        var features = {
            'Bronze': ['Basic support', 'Monthly updates', 'Email notifications', '24/7 Customer service'],
            'Silver': ['Priority support', 'Weekly updates', 'Free consultation', 'Extended warranty', 'Cloud storage', 'API access'],
            'Gold': ['24/7 support', 'Daily updates', 'Personal consultant', 'Onsite service', 'Premium content access', 'Analytics dashboard', 'Custom reports']
        };

        function selectPlan(plan) {
            var modal = document.getElementById('planModal');
            var details = document.getElementById('planDetails');
            var featuresList = document.getElementById('featuresList');
            var accumulatedFeatures = features[plan];

            modal.style.backgroundColor = {'Bronze': '#d2b48c', 'Silver': '#c0c0c0', 'Gold': '#fdd835'}[plan];
            modal.style.borderColor = {'Bronze': '#8b4513', 'Silver': '#708090', 'Gold': '#c6a700'}[plan];
            details.textContent = 'Enjoy the benefits of our ' + plan.toLowerCase() + ' package.';
            featuresList.innerHTML = '';

            accumulatedFeatures.forEach((feature, index) => {
                let div = document.createElement('div');
                let featureSpan = document.createElement('span');
                featureSpan.textContent = feature;
                featureSpan.className = 'feature';
                div.appendChild(featureSpan);

                if (index % 4 !== 0) {
                    let separator = document.createElement('div');
                    separator.className = 'separator';
                    div.insertBefore(separator, featureSpan);
                }
                featuresList.appendChild(div);
            });

            document.querySelectorAll('.plan-button').forEach(button => {
                button.style.backgroundColor = '#ffffff';
                button.style.borderColor = '#000000';
                button.style.color = '#000000';
                if (button.textContent === plan) {
                    button.style.backgroundColor = {'Bronze': '#d2b48c', 'Silver': '#c0c0c0', 'Gold': '#fdd835'}[plan];
                    button.style.borderColor = {'Bronze': '#8b4513', 'Silver': '#708090', 'Gold': '#c6a700'}[plan];
                    button.style.color = '#ffffff';
                }
            });
        }
      </script>
    </>
  );
};

export async function getStaticProps() {
  // Fetch the products from your database
  const products = await fetchProducts();
  return {
    props: {
      products,
    },
  };
}

export default Home;