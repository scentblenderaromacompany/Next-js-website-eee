import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export default async function handler(req, res) {
  try {
    const priceAlerts = await prisma.priceAlert.findMany({
      where: { notified: false },
      include: { product: true },
    });

    const notifications = [];

    for (const alert of priceAlerts) {
      const priceCheck = alert.direction === 'up' ?
        alert.product.price >= alert.threshold :
        alert.product.price <= alert.threshold;

      if (priceCheck) {
        const message = `Product ${alert.product.name} price has ${alert.direction === 'up' ? 'increased' : 'decreased'} to ${alert.product.price}. Consider adjusting the price.`;

        notifications.push(prisma.notification.create({
          data: {
            message,
            userId: 1, // Assume admin userId is 1
            read: false,
          },
        }));

        await prisma.priceAlert.update({
          where: { id: alert.id },
          data: { notified: true },
        });
      }
    }

    await prisma.$transaction(notifications);

    res.status(200).json({ message: 'Price check completed and notifications sent.' });
  } catch (error) {
    res.status(500).json({ error: 'Error checking prices.' });
  } finally {
    await prisma.$disconnect();
  }
}