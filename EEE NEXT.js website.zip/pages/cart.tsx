import React, { useState } from 'react';
import Head from 'next/head';

const Cart = () => {
  const [cartItems, setCartItems] = useState([
    // Example item
    {
      id: 1,
      name: 'Diamond Ring',
      price: 299.99,
      quantity: 1,
      image: '/images/ring.jpg',
    },
    // Add more items as needed
  ]);

  const removeItem = (id) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const updateQuantity = (id, quantity) => {
    setCartItems(cartItems.map(item => item.id === id ? { ...item, quantity } : item));
  };

  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);
  };

  return (
    <>
      <Head>
        <title>Shopping Cart - Eternal Elegance Emporium</title>
      </Head>
      <div className="container">
        <h1>Shopping Cart</h1>
        {cartItems.length === 0 ? (
          <p>Your cart is empty.</p>
        ) : (
          <>
            <ul className="cart-items">
              {cartItems.map(item => (
                <li key={item.id} className="cart-item">
                  <img src={item.image} alt={item.name} />
                  <div className="item-details">
                    <h2>{item.name}</h2>
                    <p>Price: ${item.price}</p>
                    <label>
                      Quantity:
                      <input
                        type="number"
                        value={item.quantity}
                        min="1"
                        onChange={e => updateQuantity(item.id, parseInt(e.target.value))}
                      />
                    </label>
                    <button onClick={() => removeItem(item.id)}>Remove</button>
                  </div>
                </li>
              ))}
            </ul>
            <div className="total-price">
              <h2>Total: ${getTotalPrice()}</h2>
              <button className="checkout">Proceed to Checkout</button>
            </div>
          </>
        )}
      </div>

      <style jsx>{`
        .container {
          padding: 20px;
          max-width: 800px;
          margin: auto;
        }
        .cart-items {
          list-style: none;
          padding: 0;
        }
        .cart-item {
          display: flex;
          align-items: center;
          margin-bottom: 20px;
        }
        .cart-item img {
          width: 100px;
          margin-right: 20px;
        }
        .item-details {
          flex: 1;
        }
        .item-details h2 {
          margin: 0 0 10px;
        }
      `}</style>
    </>
  );
};

export default Cart;