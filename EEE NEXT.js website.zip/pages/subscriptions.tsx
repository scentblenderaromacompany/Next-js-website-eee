import React from 'react';
import Layout from '../components/Layout';

const SubscriptionsPage = () => {
  return (
    <Layout title="Manage Subscriptions - Eternal Elegance Emporium">
      <div className="subscriptions-container">
        <h1>Manage Your Subscriptions</h1>
        {/* Add subscription management interface here */}
      </div>
    </Layout>
  );
};

export default SubscriptionsPage;