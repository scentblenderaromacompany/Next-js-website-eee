export default async function handler(req, res) {
  try {
    const products = [
      { imageUrl: 'https://example.com/product1.jpg', title: 'Vintage Ring', price: 199.99, link: 'https://ebay.com/product1' },
      { imageUrl: 'https://example.com/product2.jpg', title: 'Gold Necklace', price: 299.99, link: 'https://ebay.com/product2' },
      { imageUrl: 'https://example.com/product3.jpg', title: 'Silver Bracelet', price: 149.99, link: 'https://ebay.com/product3' },
    ];

    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch eBay products' });
  }
}