import React from 'react';
import Layout from '../components/Layout';

const ContactPage = () => {
  return (
    <Layout title="Contact Us - Eternal Elegance Emporium">
      <div className="contact-container">
        <h1>Contact Us</h1>
        <form className="contact-form">
          {/* Add form fields here */}
        </form>
      </div>
    </Layout>
  );
};

export default ContactPage;