import { useSession } from 'next-auth/client';
import { useRouter } from 'next/router';
import { useEffect } from 'react';

const AdminDashboard = () => {
  const [session, loading] = useSession();
  const router = useRouter();

  useEffect(() => {
    if (!loading && (!session || session.user.role !== 'ADMIN')) {
      router.push('/auth/signin');
    }
  }, [session, loading]);

  if (loading) return <p>Loading...</p>;

  return (
    <>
      <div className="container">
        <h1>Admin Dashboard</h1>
        {/* Rest of your dashboard content */}
      </div>
    </>
  );
};

export default AdminDashboard;