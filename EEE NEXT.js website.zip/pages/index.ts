import React from 'react';
import Head from 'next/head';
import HeroImage from '../components/HeroImage';
import ProductCarousel from '../components/ProductCarousel';
import InstagramFeed from '../components/InstagramFeed';
import EbayProducts from '../components/EbayProducts';
import SubscriptionBox from '../components/SubscriptionBox';

const Home = ({ products }) => {
  return (
    <>
      <Head>
        <title>Home - Eternal Elegance Emporium</title>
      </Head>
      <HeroImage />
      <ProductCarousel products={products} />
      <InstagramFeed />
      <EbayProducts />
      <SubscriptionBox />
    </>
  );
};

export async function getStaticProps() {
  const products = await fetchProducts(); // Mock function to get products data
  return {
    props: {
      products,
    },
  };
}

export default Home;