import React from 'react';
import Head from 'next/head';
import Link from 'next/link';

const Categories = () => {
  const categories = [
    { name: 'Rings', image: '/images/categories/rings.jpg' },
    { name: 'Necklaces', image: '/images/categories/necklaces.jpg' },
    { name: 'Bracelets', image: '/images/categories/bracelets.jpg' },
    { name: 'Earrings', image: '/images/categories/earrings.jpg' },
    { name: 'Watches', image: '/images/categories/watches.jpg' },
  ];

  return (
    <>
      <Head>
        <title>Categories - Eternal Elegance Emporium</title>
      </Head>
      <div className="container">
        <h1>Shop by Category</h1>
        <div className="categories-grid">
          {categories.map((category) => (
            <Link href={`/products?category=${category.name}`} key={category.name}>
              <a className="category-card">
                <img src={category.image} alt={category.name} />
                <h2>{category.name}</h2>
              </a>
            </Link>
          ))}
        </div>
      </div>

      <style jsx>{`
        .container {
          padding: 20px;
          max-width: 1000px;
          margin: auto;
        }
        .categories-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
        }
        .category-card {
          display: block;
          text-align: center;
          background-color: #fff;
          border: 1px solid #ccc;
          border-radius: 5px;
          padding: 20px;
          transition: transform 0.3s ease;
        }
        .category-card img {
          width: 100%;
          height: 150px;
          object-fit: cover;
          margin-bottom: 15px;
        }
        .category-card h2 {
          font-size: 1.5em;
          margin: 0;
        }
        .category-card:hover {
          transform: scale(1.05);
        }
      `}</style>
    </>
  );
};

export default Categories;