import React, { useEffect } from 'react';
import Head from 'next/head';

const FAQ = () => {
  useEffect(() => {
    const faqs = [
      { "question": "What is your return policy?", "answer": "You can return products within 30 days for a full refund." },
      { "question": "How long does shipping take?", "answer": "Shipping takes 3-5 business days." },
      { "question": "Do you provide international shipping?", "answer": "Yes, we ship internationally with additional shipping costs." },
      { "question": "How do I track my order?", "answer": "You will receive a tracking link once your order has been shipped." },
      { "question": "Are there any discounts for bulk purchases?", "answer": "Yes, discounts are available for bulk purchases. Contact sales for more details." },
      { "question": "Can I change my order after placing it?", "answer": "Orders can be modified within 24 hours of placement." },
      { "question": "What payment methods do you accept?", "answer": "We accept all major credit cards, PayPal, and bank transfers." },
      { "question": "Is there a warranty on your products?", "answer": "Yes, all products come with a one-year warranty." },
      { "question": "Can I cancel my subscription at any time?", "answer": "Yes, you can cancel your subscription without penalty." },
      { "question": "What customer support options are available?", "answer": "Customer support is available 24/7 via email, phone, and live chat." },
      { "question": "Are your products eco-friendly?", "answer": "Yes, our products are made using sustainable materials." },
      { "question": "Do you have a physical store?", "answer": "Yes, we have several physical locations worldwide." },
      { "question": "How can I apply a promo code?", "answer": "You can enter your promo code at checkout." },
      { "question": "What is your privacy policy?", "answer": "We value your privacy and do not share your information with third parties." },
      { "question": "Do you offer gift wrapping?", "answer": "Yes, gift wrapping is available for a small fee." },
      { "question": "What are your hours of operation?", "answer": "We are open 24/7 online, with customer service available from 8 AM to 8 PM." },
      { "question": "How can I return a defective product?", "answer": "Please contact customer service for a return authorization." },
      { "question": "Do you offer product replacements?", "answer": "Yes, replacements are available for defective items." },
      { "question": "How often do you restock items?", "answer": "We restock items weekly." },
      { "question": "Can I reserve an item that's out of stock?", "answer": "Yes, you can place a reservation on out-of-stock items." }
    ];

    const carousel = document.querySelector('.faq-carousel');
    let currentIndex = 0;

    faqs.forEach(faq => {
      const box = document.createElement('div');
      box.className = 'faq-box';
      box.innerHTML = `<h2>${faq.question}</h2><p>${faq.answer}</p>`;
      carousel.appendChild(box);
    });

    const nextButton = document.querySelector('.next');
    const prevButton = document.querySelector('.prev');

    nextButton.addEventListener('click', () => {
      currentIndex = (currentIndex + 1) % faqs.length;
      carousel.scrollLeft = currentIndex * carousel.offsetWidth;
    });

    prevButton.addEventListener('click', () => {
      currentIndex = (currentIndex - 1 + faqs.length) % faqs.length;
      carousel.scrollLeft = currentIndex * carousel.offsetWidth;
    });
  }, []);

  return (
    <>
      <Head>
        <title>Frequently Asked Questions - Eternal Elegance Emporium</title>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Merriweather:wght@400&display=swap" rel="stylesheet" />
      </Head>
      <div className="faq-section">
        <h1>Frequently Asked Questions</h1>
        <div className="faq-carousel">
          {/* FAQ boxes will be dynamically generated here */}
        </div>
        {/* Navigation arrows */}
        <button className="prev">&#10094;</button>
        <button className="next">&#10095;</button>
      </div>

      <style jsx>{`
        body, html {
          height: 100%;
          margin: 0;
          font-family: 'Merriweather', serif;
          font-size: 16px;
          color: #333;
          background-color: #f4e8cd;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .faq-section {
          padding: 20px;
          background-color: #eedcb3;
          width: 90%;
          max-width: 1000px;
          box-shadow: 0 4px 8px rgba(0,0,0,0.1);
          border: 5px solid #c4a678;
        }

        .faq-carousel {
          position: relative;
          width: 100%;
          height: auto;
          display: flex;
          overflow-x: auto;
          scroll-snap-type: x mandatory;
        }

        .faq-box {
          flex: 0 0 100%;
          margin: 10px 0;
          padding: 20px;
          background: white;
          border: 1px solid #c4a678;
          scroll-snap-align: start;
          box-shadow: 2px 2px 5px rgba(0,0,0,0.2);
          text-align: center;
        }

        .faq-box h2, .faq-box p {
          margin: 0;
          padding: 10px 0;
          font-family: 'Playfair Display', serif;
        }

        h2 {
          font-size: 24px;
        }

        p {
          font-size: 18px;
        }

        .prev, .next {
          cursor: pointer;
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: auto;
          padding: 16px;
          color: black;
          font-weight: bold;
          font-size: 18px;
          transition: 0.6s ease;
          user-select: none;
          background-color: #add8e6;
          border: 2px solid #4169e1;
        }

        .next {
          right: 0;
        }

        .prev {
          left: 0;
        }

        @media (max-width: 768px) {
          .faq-box {
            flex: 0 0 100%;
          }
          .prev, .next {
            display: none;
          }
        }
      `}</style>
    </>
  );
};

export default FAQ;