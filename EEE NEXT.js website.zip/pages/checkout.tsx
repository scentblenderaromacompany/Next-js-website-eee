import React, { useState } from 'react';
import Head from 'next/head';

const Checkout = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    paymentMethod: 'Credit Card',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Add your checkout logic here
    alert('Order placed successfully');
  };

  return (
    <>
      <Head>
        <title>Checkout - Eternal Elegance Emporium</title>
      </Head>
      <div className="container">
        <h1>Checkout</h1>
        <form onSubmit={handleSubmit}>
          <label>Name: <input type="text" name="name" value={formData.name} onChange={handleChange} required /></label>
          <label>Email: <input type="email" name="email" value={formData.email} onChange={handleChange} required /></label>
          <label>Address: <input type="text" name="address" value={formData.address} onChange={handleChange} required /></label>
          <label>City: <input type="text" name="city" value={formData.city} onChange={handleChange} required /></label>
          <label>State: <input type="text" name="state" value={formData.state} onChange={handleChange} required /></label>
          <label>Zip Code: <input type="text" name="zip" value={formData.zip} onChange={handleChange} required /></label>
          <label>Payment Method:
            <select name="paymentMethod" value={formData.paymentMethod} onChange={handleChange}>
              <option value="Credit Card">Credit Card</option>
              <option value="PayPal">PayPal</option>
              <option value="Bank Transfer">Bank Transfer</option>
            </select>
          </label>
          <button type="submit">Place Order</button>
        </form>
      </div>

      <style jsx>{`
        .container {
          padding: 20px;
          max-width: 600px;
          margin: auto;
        }
        form {
          display: flex;
          flex-direction: column;
        }
        label {
          margin-bottom: 15px;
        }
        input, select {
          width: 100%;
          padding: 10px;
          margin-top: 5px;
        }
        button {
          padding: 10px;
          background-color: #b69e64;
          color: white;
          border: none;
          border-radius: 5px;
          cursor: pointer;
        }
      `}</style>
    </>
  );
};

export default Checkout;