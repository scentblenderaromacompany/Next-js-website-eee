import { signIn, useSession } from 'next-auth/client';
import { useRouter } from 'next/router';
import { useEffect } from 'react';

export default function SignIn() {
  const [session] = useSession();
  const router = useRouter();

  useEffect(() => {
    if (session) {
      router.push('/');
    }
  }, [session]);

  return (
    <div className="container">
      <h1>Sign In</h1>
      <button onClick={() => signIn('email', { callbackUrl: '/' })}>
        Sign in with Email
      </button>

      <style jsx>{`
        .container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          padding: 20px;
        }
        h1 {
          margin-bottom: 20px;
        }
        button {
          padding: 10px 20px;
          background-color: #b69e64;
          color: white;
          border: none;
          border-radius: 5px;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}