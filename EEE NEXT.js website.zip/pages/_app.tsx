import React from 'react';
import AnnouncementBar from '../components/AnnouncementBar';
import Navbar from '../components/Navbar';
import HeroImage from '../components/HeroImage';
import ProductCarousel from '../components/ProductCarousel';
import ProductRecommendations from '../components/ProductRecommendations';
import InstagramFeed from '../components/InstagramFeed';
import EbayProducts from '../components/EbayProducts';
import Search from '../components/Search';
import Wishlist from '../components/Wishlist';
import '../app/globals.css';

const MyApp = ({ Component, pageProps }) => {
  return (
    <>
      <AnnouncementBar />
      <Navbar />
      <HeroImage />
      <ProductCarousel products={pageProps.products} />
      <Search />
      <Wishlist userId={pageProps.userId} />
      <ProductRecommendations products={pageProps.products} userId={pageProps.userId} />
      <InstagramFeed />
      <EbayProducts />
      <Component {...pageProps} />
    </>
  );
};

export async function getStaticProps() {
  // Fetch the products from your database
  const products = await fetchProducts();
  return {
    props: {
      products,
      userId: 1, // Replace with actual user ID logic
    },
  };
}

export default MyApp;