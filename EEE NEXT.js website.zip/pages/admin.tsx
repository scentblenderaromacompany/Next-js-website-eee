import React from 'react';
import Layout from '../components/Layout';

const AdminPage = () => {
  return (
    <Layout title="Admin Dashboard - Eternal Elegance Emporium">
      <div className="admin-dashboard">
        <h1>Admin Dashboard</h1>
        {/* Add admin controls for products, orders, and reviews here */}
      </div>
    </Layout>
  );
};

export default AdminPage;