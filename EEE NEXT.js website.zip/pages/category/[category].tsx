import React from 'react';
import Layout from '../../components/Layout';
import Link from 'next/link';

const CategoryPage = ({ category, products }) => {
  return (
    <Layout title={`${category} - Eternal Elegance Emporium`}>
      <div className="carousel slide" id="categoryCarousel" data-bs-ride="carousel">
        <div className="carousel-inner">
          {products.map((product, index) => (
            <div className={`carousel-item ${index === 0 ? 'active' : ''}`} key={product.id}>
              <img src={product.image} className="d-block w-100" alt={product.name} />
              <div className="carousel-caption d-none d-md-block">
                <h5>{product.name}</h5>
                <p>{product.description}</p>
              </div>
            </div>
          ))}
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#categoryCarousel" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#categoryCarousel" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>

      <div className="product-grid mt-5">
        <div className="row">
          {products.map((product) => (
            <div className="col-md-4 mb-4" key={product.id}>
              <div className="card">
                <img src={product.image} className="card-img-top" alt={product.name} />
                <div className="card-body">
                  <h5 className="card-title">{product.name}</h5>
                  <p className="card-text">{product.description}</p>
                  <Link href={`/product/${product.slug}`}>
                    <a className="btn btn-primary">View Details</a>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export async function getStaticProps({ params }) {
  const category = params.category;
  // Fetch products by category from your API
  const products = await fetchProductsByCategory(category);
  return {
    props: {
      category,
      products,
    },
  };
}

export async function getStaticPaths() {
  const categories = ['Rings', 'Necklaces', 'Bracelets', 'Earrings', 'Watches'];
  const paths = categories.map(category => ({
    params: { category },
  }));

  return { paths, fallback: false };
}

export default CategoryPage;