import React, { useState, useEffect } from 'react';
import Head from 'next/head';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState('All');
  const [totalSpent, setTotalSpent] = useState(0);

  useEffect(() => {
    fetchOrders();
  }, [filter]);

  const fetchOrders = async () => {
    const res = await fetch('/api/orders');
    const data = await res.json();
    const filteredOrders = filter === 'All' ? data : data.filter(order => order.status === filter);
    setOrders(filteredOrders);
    calculateTotalSpent(filteredOrders);
  };

  const calculateTotalSpent = (orders) => {
    const total = orders.reduce((sum, order) => sum + order.totalPrice, 0);
    setTotalSpent(total.toFixed(2));
  };

  return (
    <>
      <Head>
        <title>My Orders - Eternal Elegance Emporium</title>
      </Head>
      <div className="container">
        <h1>My Orders</h1>
        <div className="filter-container">
          <label>Filter by Status:</label>
          <select onChange={(e) => setFilter(e.target.value)} value={filter}>
            <option value="All">All</option>
            <option value="Pending">Pending</option>
            <option value="Shipped">Shipped</option>
            <option value="Delivered">Delivered</option>
          </select>
        </div>
        {orders.length === 0 ? (
          <p>No orders found.</p>
        ) : (
          <>
            <ul className="orders-list">
              {orders.map(order => (
                <li key={order.id} className="order-item">
                  <h2>Order #{order.id}</h2>
                  <p>Status: {order.status}</p>
                  <p>Total Price: ${order.totalPrice.toFixed(2)}</p>
                  <p>Date: {new Date(order.createdAt).toLocaleDateString()}</p>
                  <h3>Items:</h3>
                  <ul>
                    {order.items.map(item => (
                      <li key={item.id}>
                        {item.name} - ${item.price.toFixed(2)} x {item.quantity}
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
            <div className="summary">
              <h2>Total Spent: ${totalSpent}</h2>
            </div>
          </>
        )}
      </div>

      <style jsx>{`
        .container {
          padding: 20px;
          max-width: 800px;
          margin: auto;
        }
        .filter-container {
          margin-bottom: 20px;
        }
        .orders-list {
          list-style: none;
          padding: 0;
        }
        .order-item {
          padding: 15px;
          background-color: #fff;
          border: 1px solid #ccc;
          border-radius: 5px;
          margin-bottom: 15px;
        }
        .summary {
          margin-top: 20px;
          font-size: 1.5em;
          text-align: right;
        }
      `}</style>
    </>
  );
};

export default Orders;