import React from 'react';
import { GetStaticProps } from 'next';
import { fetchProducts } from '../lib/stripe';
import ProductCard from '../components/ProductCard';

const Home = ({ products }) => {
  return (
    <div className="container mx-auto">
      <h1 className="text-3xl font-bold text-primary my-6">Welcome to Your Jewelry Store</h1>
      <p className="text-lg text-secondary">Discover unique, pre-loved jewelry pieces at unbeatable prices.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 my-8">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export const getStaticProps: GetStaticProps = async () => {
  const products = await fetchProducts(); // Fetch products from Stripe
  return {
    props: {
      products,
    },
  };
};

export default Home;