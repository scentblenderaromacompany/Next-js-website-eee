import React from 'react';
import Link from 'next/link';

const ProductCarousel = ({ products }) => {
  return (
    <div className="product-carousel">
      <div className="carousel">
        {products.map((product, index) => (
          <div className="carousel-item" key={index}>
            <Link href={`/products/${product.slug}`}>
              <img src={product.images[0]} alt={product.name} className="w-full h-64 object-cover" />
              <h2 className="text-lg font-bold text-primary mt-2">{product.name}</h2>
              <p className="text-secondary mt-2">Price: \${product.price.toFixed(2)}</p>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductCarousel;