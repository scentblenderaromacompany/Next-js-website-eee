import React, { useEffect, useState } from 'react';

const EbayProducts = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch eBay products data here
    fetch('/api/ebay')
      .then(response => response.json())
      .then(data => setProducts(data));
  }, []);

  return (
    <div className="ebay-products">
      <h2>Featured eBay Listings</h2>
      <div className="product-list">
        {products.map((product, index) => (
          <div className="product-card" key={index}>
            <img src={product.imageUrl} alt={product.title} />
            <h3>{product.title}</h3>
            <p>\${product.price}</p>
            <a href={product.link} target="_blank" rel="noopener noreferrer">View on eBay</a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EbayProducts;