import React, { useEffect, useState } from 'react';

const Wishlist = ({ userId }) => {
  const [wishlist, setWishlist] = useState([]);

  useEffect(() => {
    fetch(`/api/wishlist?userId=${userId}`)
      .then(response => response.json())
      .then(data => setWishlist(data));
  }, [userId]);

  return (
    <div className="wishlist">
      <h2>Your Wishlist</h2>
      <div className="product-list">
        {wishlist.map((item, index) => (
          <div className="product-card" key={index}>
            <img src={item.product.image} alt={item.product.name} />
            <h3>{item.product.name}</h3>
            <p>\${item.product.price.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Wishlist;