import React from 'react';
import Head from 'next/head';

const Layout = ({ children, title = 'Eternal Elegance Emporium' }) => {
  return (
    <>
      <Head>
        <title>{title}</title>
        <link
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
          rel="stylesheet"
        />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
      </Head>
      <div className="container mx-auto">{children}</div>
    </>
  );
};

export default Layout;