import React from 'react';
import Link from 'next/link';

const ProductCard = ({ product }) => {
  return (
    <div className="border p-4 rounded-lg">
      <Link href={`/products/${product.slug}`}>
        <img src={product.images[0]} alt={product.name} className="w-full h-64 object-cover" />
        <h2 className="text-lg font-bold text-primary mt-2">{product.name}</h2>
      </Link>
      <p className="text-secondary mt-2">Price: \${product.price / 100}</p>
    </div>
  );
};

export default ProductCard;