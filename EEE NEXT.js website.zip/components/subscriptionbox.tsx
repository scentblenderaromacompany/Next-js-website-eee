import React from 'react';

const SubscriptionBox = () => {
    return (
        <div className="subscription-container">
      <header>Subscribe Today And Join Our Community!</header>
      <div className="modal" id="planModal">
        <main id="planDetails">Please select a plan below to see the details.</main>
      </div>
      <div className="features-list" id="featuresList"></div>
      <div idIt seems the previous response was cut off before completing the `SubscriptionBox` component. Let me finish that and then proceed with debugging and enhancing the rest of your files.

### 6. **Finalizing the `SubscriptionBox.tsx` Component**

Here's the complete `SubscriptionBox.tsx` component:

```bash
# Create or update SubscriptionBox component
cat > components/SubscriptionBox.tsx <<'EOL'
import React, { useState } from 'react';

const SubscriptionBox = () => {
  const [selectedPlan, setSelectedPlan] = useState('Bronze');
  const features = {
    'Bronze': ['Basic support', 'Monthly updates', 'Email notifications', '24/7 Customer service'],
    'Silver': ['Priority support', 'Weekly updates', 'Free consultation', 'Extended warranty', 'Cloud storage', 'API access'],
    'Gold': ['24/7 support', 'Daily updates', 'Personal consultant', 'Onsite service', 'Premium content access', 'Analytics dashboard', 'Custom reports']
  };

  const handlePlanChange = (plan) => {
    setSelectedPlan(plan);
  };

  return (
    <div className="subscription-container">
      <header>Subscribe Today And Join Our Community!</header>
      <div className="modal" style={{ backgroundColor: getBackgroundColor(selectedPlan) }}>
        <main>{`Enjoy the benefits of our ${selectedPlan} package.`}</main>
      </div>
      <div className="features-list">
        {features[selectedPlan].map((feature, index) => (
          <div key={index} className="feature">
            {index > 0 && <div className="separator" />}
            {feature}
          </div>
        ))}
      </div>
      <div id="buttonsContainer">
        {Object.keys(features).map(plan => (
          <button 
            key={plan} 
            className={`plan-button ${selectedPlan === plan ? 'active' : ''}`} 
            onClick={() => handlePlanChange(plan)}
          >
            {plan}
          </button>
        ))}
      </div>

      <style jsx>{`
        .subscription-container {
          padding: 50px 20px;
          background-color: #f0e6d2;
          text-align: center;
          border-top: 2px solid #c4a678;
          border-bottom: 2px solid #c4a678;
          margin: 50px 0;
        }
        header {
          font-family: 'Playfair Display', serif;
          font-size: 36px;
          font-weight: bold;
          margin-bottom: 30px;
        }
        .modal {
          padding: 12px;
          border: 2px solid #8b4513;
          width: 270px;
          height: 180px;
          margin: 0 auto 30px;
          display: flex;
          justify-content: center;
          align-items: center;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        .features-list {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          margin: 0 auto 10px;
        }
        .feature {
          margin: 0 10px;
          color: black;
          display: flex;
          align-items: center;
        }
        .separator {
          height: 20px;
          width: 1px;
          background-color: #000;
          margin: 0 5px;
        }
        .plan-button {
          padding: 8px 16px;
          margin: 4px;
          border: 2px solid #000;
          background-color: #fff;
          color: black;
          cursor: pointer;
          font-size: 14px;
          transition: background-color 0.3s, color 0.3s, border-color 0.3s;
        }
        .plan-button:hover, .plan-button.active {
          background-color: var(--color-accent);
          color: white;
          border-color: var(--color-primary);
        }
      `}</style>
    </div>
  );

  function getBackgroundColor(plan) {
    switch(plan) {
      case 'Bronze':
        return '#d2b48c';
      case 'Silver':
        return '#c0c0c0';
      case 'Gold':
        return '#fdd835';
      default:
        return '#f0e6d2';
    }
  }
};

export default SubscriptionBox;