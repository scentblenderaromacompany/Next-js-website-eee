import React from 'react';

const HeroImage = () => {
  return (
    <div className="hero-image">
      <h1>Welcome to Eternal Elegance</h1>
      <p>Discover the finest jewelry, crafted with precision and care.</p>
    </div>
  );
};

export default HeroImage;