import React from 'react';
import Link from 'next/link';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="container">
        <Link href="/" className="navbar-brand">
          Eternal Elegance Emporium
        </Link>
        <ul className="navbar-nav ml-auto">
          <li className="nav-item">
            <Link href="/" className="nav-link">
              Home
            </Link>
          </li>
          <li className="nav-item">
            <Link href="/products/rings" className="nav-link">
              Rings
            </Link>
          </li>
          <li className="nav-item">
            <Link href="/products/necklaces" className="nav-link">
              Necklaces
            </Link>
          </li>
          <li className="nav-item">
            <Link href="/products/bracelets" className="nav-link">
              Bracelets
            </Link>
          </li>
          <li className="nav-item">
            <Link href="/products/handmade" className="nav-link">
              Handmade
            </Link>
          </li>
          <li className="nav-item">
            <Link href="/products/earrings" className="nav-link">
              Earrings
            </Link>
          </li>
          <li className="nav-item">
            <Link href="/products/watches" className="nav-link">
              Watches
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;