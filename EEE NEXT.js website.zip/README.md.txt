Eternal Elegance Emporium

Welcome to the Eternal Elegance Emporium! This is a full-featured e-commerce website for reselling pre-owned jewelry, built using Next.js, TypeScript, Tailwind CSS, and Bootstrap. This guide will walk you through setting up, running, and deploying the project.

Table of Contents

	1.	Project Structure
	2.	Installation
	3.	Configuration
	4.	Running the Project
	5.	Folder and File Descriptions
	6.	Available Scripts
	7.	API Routes
	8.	Deployment
	9.	Environment Variables
	10.	Contributing
	11.	License

Project Structure

Here’s an overview of the project structure:

|-- components/        # Reusable React components
|   |-- Layout.tsx     # Layout component used across pages
|
|-- pages/             # Next.js pages (each file becomes a route)
|   |-- api/           # API routes for server-side logic
|   |-- cart.tsx       # Shopping Cart page
|   |-- checkout.tsx   # Checkout page
|   |-- orders.tsx     # Orders page for users
|   |-- product/       # Product-related pages
|   |   |-- [slug].tsx # Product detail page
|   |-- category/      # Category-related pages
|   |   |-- [category].tsx # Category listing page
|   |-- index.tsx      # Home page
|   |-- _app.tsx       # Custom App component for global setup
|   |-- _document.tsx  # Custom Document component for HTML setup
|
|-- public/            # Static files such as images, fonts, etc.
|   |-- images/        # Image assets for the site
|
|-- styles/            # Global styles and Tailwind CSS setup
|   |-- globals.css    # Global CSS styles
|
|-- prisma/            # Database schema and migration files
|   |-- schema.prisma  # Prisma schema file
|
|-- .env.local         # Environment variables (not included in source control)
|-- next.config.js     # Next.js configuration
|-- tsconfig.json      # TypeScript configuration
|-- package.json       # Project metadata and dependencies
|-- README.md          # Project documentation (this file)

Installation

Prerequisites
Let’s start by defining the database schema using Prisma, which will manage the database models and relationships for your jewelry e-commerce website. The schema will include:

	1.	User Model: Represents users in the system.
	2.	Profile Model: Additional user profile information.
	3.	Product Model: Represents jewelry items available for sale.
	4.	Order Model: Tracks sales and orders placed by users.
	5.	OrderItem Model: Represents individual items within an order.
	6.	Category Model: Represents categories for jewelry (e.g., Rings, Necklaces).
	7.	SalesHistory Model: Tracks the sales history for each product.

1. Prisma Schema (schema.prisma)

I’ll define the schema first, then update the README.md with detailed instructions.

File: prisma/schema.prisma

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql" // Or use your preferred database provider
  url      = env("DATABASE_URL")
}

model User {
  id        Int      @id @default(autoincrement())
  email     String   @unique
  password  String
  name      String?
  profile   Profile?
  orders    Order[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Profile {
  id        Int    @id @default(autoincrement())
  userId    Int    @unique
  user      User   @relation(fields: [userId], references: [id])
  bio       String?
  avatarUrl String?
}

model Product {
  id          Int          @id @default(autoincrement())
  name        String
  description String
  price       Float
  imageUrl    String
  categoryId  Int
  category    Category     @relation(fields: [categoryId], references: [id])
  salesHistory SalesHistory[]
  createdAt   DateTime     @default(now())
  updatedAt   DateTime     @updatedAt
}

model Order {
  id         Int          @id @default(autoincrement())
  userId     Int
  user       User         @relation(fields: [userId], references: [id])
  orderItems OrderItem[]
  totalPrice Float
  status     String
  createdAt  DateTime     @default(now())
  updatedAt  DateTime     @updatedAt
}

model OrderItem {
  id        Int      @id @default(autoincrement())
  orderId   Int
  productId Int
  order     Order    @relation(fields: [orderId], references: [id])
  product   Product  @relation(fields: [productId], references: [id])
  quantity  Int
  price     Float
}

model Category {
  id       Int       @id @default(autoincrement())
  name     String
  products Product[]
}

model SalesHistory {
  id        Int      @id @default(autoincrement())
  productId Int
  product   Product  @relation(fields: [productId], references: [id])
  saleDate  DateTime @default(now())
  quantity  Int
  price     Float
}

2. Updated README.md

Now, I’ll update the README.md with detailed instructions on how to set up and use the Prisma-based database.

Eternal Elegance Emporium

Welcome to the Eternal Elegance Emporium! This is a full-featured e-commerce website for reselling pre-owned jewelry, built using Next.js, TypeScript, Prisma, Tailwind CSS, and Bootstrap. This guide will walk you through setting up, running, and deploying the project.

Table of Contents

	1.	Project Structure
	2.	Installation
	3.	Configuration
	4.	Running the Project
	5.	Folder and File Descriptions
	6.	Available Scripts
	7.	API Routes
	8.	Database Setup with Prisma
	9.	Deployment
	10.	Environment Variables
	11.	Contributing
	12.	License

Project Structure

Here’s an overview of the project structure:

|-- components/        # Reusable React components
|   |-- Layout.tsx     # Layout component used across pages
|
|-- pages/             # Next.js pages (each file becomes a route)
|   |-- api/           # API routes for server-side logic
|   |-- cart.tsx       # Shopping Cart page
|   |-- checkout.tsx   # Checkout page
|   |-- orders.tsx     # Orders page for users
|   |-- product/       # Product-related pages
|   |   |-- [slug].tsx # Product detail page
|   |-- category/      # Category-related pages
|   |   |-- [category].tsx # Category listing page
|   |-- index.tsx      # Home page
|   |-- _app.tsx       # Custom App component for global setup
|   |-- _document.tsx  # Custom Document component for HTML setup
|
|-- public/            # Static files such as images, fonts, etc.
|   |-- images/        # Image assets for the site
|
|-- styles/            # Global styles and Tailwind CSS setup
|   |-- globals.css    # Global CSS styles
|
|-- prisma/            # Database schema and migration files
|   |-- schema.prisma  # Prisma schema file
|
|-- .env.local         # Environment variables (not included in source control)
|-- next.config.js     # Next.js configuration
|-- tsconfig.json      # TypeScript configuration
|-- package.json       # Project metadata and dependencies
|-- README.md          # Project documentation (this file)

Installation

Prerequisites

Ensure you have the following installed:

	•	Node.js: v14.x or higher
	•	npm or Yarn: npm comes with Node.js, or you can install Yarn.

Steps

	1.	Clone the repository:

git clone https://github.com/yourusername/yournextstore.git
cd yournextstore


	2.	Install dependencies:

npm install
# or
yarn install


	3.	Set up environment variables:
Create a .env.local file in the root of your project and add the following:

DATABASE_URL="postgresql://user:password@localhost:5432/dbname"
STRIPE_SECRET_KEY="your_stripe_secret_key"
STRIPE_PUBLISHABLE_KEY="your_stripe_publishable_key"

Replace the values with your actual database credentials and Stripe API keys.

Configuration

1. Prisma Configuration

The Prisma configuration is defined in prisma/schema.prisma. This file defines all the models (User, Product, Order, etc.) and their relationships. The DATABASE_URL is set in your .env.local file.

2. Next.js Configuration

The next.config.js file contains custom configuration options for Next.js.

3. TypeScript Configuration

The tsconfig.json file configures TypeScript settings.

Running the Project

1. Set up the Database

First, ensure your PostgreSQL (or another database) is running. Then, run the following commands to set up the database:

npx prisma migrate dev --name init
npx prisma generate

This will create the necessary database tables based on the Prisma schema.

2. Start the Development Server

Run the development server:

npm run dev
# or
yarn dev

Open http://localhost:3000 with your browser to see the result.

Folder and File Descriptions

	•	components/Layout.tsx: The layout component used for consistent page layout.
	•	pages/index.tsx: The homepage.
	•	pages/cart.tsx: The shopping cart page.
	•	pages/checkout.tsx: The checkout page.
	•	pages/orders.tsx: The orders page.
	•	pages/product/[slug].tsx: The product detail page.
	•	pages/category/[category].tsx: The category page.
	•	prisma/schema.prisma: The Prisma schema that defines the database models.
	•	next.config.js: Custom Next.js configuration.
	•	tsconfig.json: TypeScript configuration.

Available Scripts

	•	npm run dev: Runs the app in development mode.
	•	npm run build: Builds the app for production.
	•	npm start: Starts the production build.
	•	npm run lint: Lints the codebase.

API Routes

	•	/api/products: Fetch products.
	•	/api/orders: Fetch and manage orders.
	•	/api/users: User-related operations.

Database Setup with Prisma

	1.	Migrate the Database:
Run the following command to apply the database migrations:

npx prisma migrate dev --name init


	2.	Generate Prisma Client:
Generate the Prisma Client based on the schema:

npx prisma generate


	3.	Seed the Database (Optional):
You can create a seed file in prisma/seed.ts to populate your database with initial data.

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Add seeding logic here
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });



Deployment

To deploy the project, follow these steps:

	1.	Build the Project:

npm run build


	2.	Deploy to Vercel:
Deploy the project using Vercel:

npx vercel


	3.	Set Environment Variables:
Ensure that all necessary environment variables (e.g., DATABASE_URL, STRIPE_SECRET_KEY) are set in your deployment environment.

Environment Variables

	•	DATABASE_URL: Connection string for your database.
	•	STRIPE_SECRET_KEY: Secret key for Stripe payment processing.
	•	STRIPE_PUBLISHABLE_KEY: Publishable key for Stripe payment processing.

Contributing

Contributions are welcome! Please open an issue or submit a pull request.

License

This project is licensed under the MIT License.